﻿namespace ProyectoFinal
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.tdir = new System.Windows.Forms.TextBox();
            this.grillapersaut = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tnom = new System.Windows.Forms.TextBox();
            this.tcipersaut = new System.Windows.Forms.TextBox();
            this.brevprof = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bregtelf = new System.Windows.Forms.Button();
            this.telf = new System.Windows.Forms.TextBox();
            this.grillatelf = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tid = new System.Windows.Forms.TextBox();
            this.tci = new System.Windows.Forms.TextBox();
            this.btelf = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.grillabanco = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tnumc = new System.Windows.Forms.TextBox();
            this.tci2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.cbmon = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cbtipoc = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tban = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.grillapersaut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillatelf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillabanco)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(70, 250);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 32);
            this.button2.TabIndex = 58;
            this.button2.Text = "Registrar Encargado";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tdir
            // 
            this.tdir.Location = new System.Drawing.Point(124, 209);
            this.tdir.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tdir.Name = "tdir";
            this.tdir.Size = new System.Drawing.Size(196, 20);
            this.tdir.TabIndex = 57;
            // 
            // grillapersaut
            // 
            this.grillapersaut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillapersaut.Location = new System.Drawing.Point(451, 100);
            this.grillapersaut.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillapersaut.Name = "grillapersaut";
            this.grillapersaut.RowHeadersWidth = 51;
            this.grillapersaut.RowTemplate.Height = 24;
            this.grillapersaut.Size = new System.Drawing.Size(438, 206);
            this.grillapersaut.TabIndex = 56;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(68, 78);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 13);
            this.label7.TabIndex = 55;
            this.label7.Text = "Registrar un nuevo encargado";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 214);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 54;
            this.label6.Text = "Dirección:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 159);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 13);
            this.label4.TabIndex = 52;
            this.label4.Text = "Nombre de la Persona:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 115);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 51;
            this.label3.Text = "CI Persona:";
            // 
            // tnom
            // 
            this.tnom.Location = new System.Drawing.Point(124, 157);
            this.tnom.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tnom.Name = "tnom";
            this.tnom.Size = new System.Drawing.Size(196, 20);
            this.tnom.TabIndex = 50;
            // 
            // tcipersaut
            // 
            this.tcipersaut.Location = new System.Drawing.Point(124, 112);
            this.tcipersaut.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tcipersaut.Name = "tcipersaut";
            this.tcipersaut.Size = new System.Drawing.Size(196, 20);
            this.tcipersaut.TabIndex = 49;
            this.tcipersaut.Text = "100-XXX";
            this.tcipersaut.TextChanged += new System.EventHandler(this.tcipersaut_TextChanged);
            // 
            // brevprof
            // 
            this.brevprof.Location = new System.Drawing.Point(634, 41);
            this.brevprof.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.brevprof.Name = "brevprof";
            this.brevprof.Size = new System.Drawing.Size(111, 40);
            this.brevprof.TabIndex = 48;
            this.brevprof.Text = "Revisar Encargados Existentes";
            this.brevprof.UseVisualStyleBackColor = true;
            this.brevprof.Click += new System.EventHandler(this.brevprof_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(268, 54);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 47;
            this.label2.Text = "¿Qué quiere hacer?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(268, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 13);
            this.label1.TabIndex = 46;
            this.label1.Text = "Reigistrar Personas Autorizadas";
            // 
            // bregtelf
            // 
            this.bregtelf.Location = new System.Drawing.Point(70, 534);
            this.bregtelf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bregtelf.Name = "bregtelf";
            this.bregtelf.Size = new System.Drawing.Size(139, 32);
            this.bregtelf.TabIndex = 68;
            this.bregtelf.Text = "Registrar Teléfono";
            this.bregtelf.UseVisualStyleBackColor = true;
            this.bregtelf.Click += new System.EventHandler(this.bregtelf_Click);
            // 
            // telf
            // 
            this.telf.Location = new System.Drawing.Point(124, 492);
            this.telf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.telf.Name = "telf";
            this.telf.Size = new System.Drawing.Size(196, 20);
            this.telf.TabIndex = 67;
            // 
            // grillatelf
            // 
            this.grillatelf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillatelf.Location = new System.Drawing.Point(451, 386);
            this.grillatelf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillatelf.Name = "grillatelf";
            this.grillatelf.RowHeadersWidth = 51;
            this.grillatelf.RowTemplate.Height = 24;
            this.grillatelf.Size = new System.Drawing.Size(438, 206);
            this.grillatelf.TabIndex = 66;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 378);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 65;
            this.label5.Text = "Registrar Teléfono";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 496);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 13);
            this.label8.TabIndex = 64;
            this.label8.Text = "Número de teléfono:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 459);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 63;
            this.label9.Text = "ID del teléfono:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 414);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 13);
            this.label10.TabIndex = 62;
            this.label10.Text = "CI Persona:";
            // 
            // tid
            // 
            this.tid.Location = new System.Drawing.Point(124, 457);
            this.tid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tid.Name = "tid";
            this.tid.Size = new System.Drawing.Size(196, 20);
            this.tid.TabIndex = 61;
            this.tid.Text = "200-XXX";
            // 
            // tci
            // 
            this.tci.Location = new System.Drawing.Point(124, 412);
            this.tci.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tci.Name = "tci";
            this.tci.Size = new System.Drawing.Size(196, 20);
            this.tci.TabIndex = 60;
            this.tci.Text = "100-XXX";
            // 
            // btelf
            // 
            this.btelf.Location = new System.Drawing.Point(634, 341);
            this.btelf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btelf.Name = "btelf";
            this.btelf.Size = new System.Drawing.Size(111, 40);
            this.btelf.TabIndex = 59;
            this.btelf.Text = "Revisar Teléfonos Existentes";
            this.btelf.UseVisualStyleBackColor = true;
            this.btelf.Click += new System.EventHandler(this.btelf_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(76, 863);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 32);
            this.button1.TabIndex = 78;
            this.button1.Text = "Registrar Cuenta Bancaria";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grillabanco
            // 
            this.grillabanco.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillabanco.Location = new System.Drawing.Point(451, 649);
            this.grillabanco.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillabanco.Name = "grillabanco";
            this.grillabanco.RowHeadersWidth = 51;
            this.grillabanco.RowTemplate.Height = 24;
            this.grillabanco.Size = new System.Drawing.Size(438, 206);
            this.grillabanco.TabIndex = 76;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(68, 641);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 13);
            this.label11.TabIndex = 75;
            this.label11.Text = "Registrar Cuenta Bancaria";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 760);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 13);
            this.label12.TabIndex = 74;
            this.label12.Text = "Tipo de moneda:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 722);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 13);
            this.label13.TabIndex = 73;
            this.label13.Text = "Número de cuenta:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 678);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 13);
            this.label14.TabIndex = 72;
            this.label14.Text = "CI Persona:";
            // 
            // tnumc
            // 
            this.tnumc.Location = new System.Drawing.Point(124, 720);
            this.tnumc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tnumc.Name = "tnumc";
            this.tnumc.Size = new System.Drawing.Size(196, 20);
            this.tnumc.TabIndex = 71;
            // 
            // tci2
            // 
            this.tci2.Location = new System.Drawing.Point(124, 675);
            this.tci2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tci2.Name = "tci2";
            this.tci2.Size = new System.Drawing.Size(196, 20);
            this.tci2.TabIndex = 70;
            this.tci2.Text = "100-XXX";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(634, 604);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 40);
            this.button3.TabIndex = 69;
            this.button3.Text = "Revisar Cuentas Existentes";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // cbmon
            // 
            this.cbmon.FormattingEnabled = true;
            this.cbmon.Location = new System.Drawing.Point(124, 760);
            this.cbmon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbmon.Name = "cbmon";
            this.cbmon.Size = new System.Drawing.Size(92, 21);
            this.cbmon.TabIndex = 79;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 802);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 13);
            this.label15.TabIndex = 80;
            this.label15.Text = "Tipo de cuenta:";
            // 
            // cbtipoc
            // 
            this.cbtipoc.FormattingEnabled = true;
            this.cbtipoc.Location = new System.Drawing.Point(124, 802);
            this.cbtipoc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbtipoc.Name = "cbtipoc";
            this.cbtipoc.Size = new System.Drawing.Size(92, 21);
            this.cbtipoc.TabIndex = 81;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 840);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 13);
            this.label16.TabIndex = 83;
            this.label16.Text = "Banco:";
            // 
            // tban
            // 
            this.tban.Location = new System.Drawing.Point(124, 838);
            this.tban.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tban.Name = "tban";
            this.tban.Size = new System.Drawing.Size(196, 20);
            this.tban.TabIndex = 82;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(915, 371);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.tban);
            this.Controls.Add(this.cbtipoc);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cbmon);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.grillabanco);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tnumc);
            this.Controls.Add(this.tci2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.bregtelf);
            this.Controls.Add(this.telf);
            this.Controls.Add(this.grillatelf);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tid);
            this.Controls.Add(this.tci);
            this.Controls.Add(this.btelf);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tdir);
            this.Controls.Add(this.grillapersaut);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tnom);
            this.Controls.Add(this.tcipersaut);
            this.Controls.Add(this.brevprof);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form4";
            this.Text = "Registrar Personas Autorizadas";
            ((System.ComponentModel.ISupportInitialize)(this.grillapersaut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillatelf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillabanco)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tdir;
        private System.Windows.Forms.DataGridView grillapersaut;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tnom;
        private System.Windows.Forms.TextBox tcipersaut;
        private System.Windows.Forms.Button brevprof;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bregtelf;
        private System.Windows.Forms.TextBox telf;
        private System.Windows.Forms.DataGridView grillatelf;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tid;
        private System.Windows.Forms.TextBox tci;
        private System.Windows.Forms.Button btelf;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView grillabanco;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tnumc;
        private System.Windows.Forms.TextBox tci2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox cbmon;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cbtipoc;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tban;
    }
}