﻿namespace ProyectoFinal
{
    partial class Comida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.breging = new System.Windows.Forms.Button();
            this.tiding = new System.Windows.Forms.TextBox();
            this.ting = new System.Windows.Forms.TextBox();
            this.grillaing = new System.Windows.Forms.DataGridView();
            this.bing = new System.Windows.Forms.Button();
            this.bplat = new System.Windows.Forms.Button();
            this.grillaplato = new System.Windows.Forms.DataGridView();
            this.tplat = new System.Windows.Forms.TextBox();
            this.tidplat = new System.Windows.Forms.TextBox();
            this.bregplat = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bmen = new System.Windows.Forms.Button();
            this.grillamen = new System.Windows.Forms.DataGridView();
            this.tmen = new System.Windows.Forms.TextBox();
            this.tnummen = new System.Windows.Forms.TextBox();
            this.bregmen = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tpre = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.brec = new System.Windows.Forms.Button();
            this.grillarec = new System.Windows.Forms.DataGridView();
            this.tidplat2 = new System.Windows.Forms.TextBox();
            this.tiding2 = new System.Windows.Forms.TextBox();
            this.bregrec = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.grillacont = new System.Windows.Forms.DataGridView();
            this.tidplat3 = new System.Windows.Forms.TextBox();
            this.tnmen = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.grillacons = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.tnmen2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tmat = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tcan = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.bregcons = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.tfcon = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.grillaing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillaplato)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillamen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillarec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacont)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacons)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Ingrediente:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre Ingrediente:";
            // 
            // breging
            // 
            this.breging.Location = new System.Drawing.Point(320, 50);
            this.breging.Margin = new System.Windows.Forms.Padding(4);
            this.breging.Name = "breging";
            this.breging.Size = new System.Drawing.Size(151, 28);
            this.breging.TabIndex = 2;
            this.breging.Text = "Registrar Ingrediente";
            this.breging.UseVisualStyleBackColor = true;
            this.breging.Click += new System.EventHandler(this.breging_Click);
            // 
            // tiding
            // 
            this.tiding.Location = new System.Drawing.Point(163, 16);
            this.tiding.Margin = new System.Windows.Forms.Padding(4);
            this.tiding.Name = "tiding";
            this.tiding.Size = new System.Drawing.Size(132, 22);
            this.tiding.TabIndex = 3;
            this.tiding.Text = "000XX";
            // 
            // ting
            // 
            this.ting.Location = new System.Drawing.Point(163, 53);
            this.ting.Margin = new System.Windows.Forms.Padding(4);
            this.ting.Name = "ting";
            this.ting.Size = new System.Drawing.Size(132, 22);
            this.ting.TabIndex = 4;
            // 
            // grillaing
            // 
            this.grillaing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaing.Location = new System.Drawing.Point(21, 107);
            this.grillaing.Margin = new System.Windows.Forms.Padding(4);
            this.grillaing.Name = "grillaing";
            this.grillaing.RowHeadersWidth = 51;
            this.grillaing.Size = new System.Drawing.Size(449, 185);
            this.grillaing.TabIndex = 5;
            // 
            // bing
            // 
            this.bing.Location = new System.Drawing.Point(145, 299);
            this.bing.Margin = new System.Windows.Forms.Padding(4);
            this.bing.Name = "bing";
            this.bing.Size = new System.Drawing.Size(151, 28);
            this.bing.TabIndex = 6;
            this.bing.Text = "Mostrar Ingredeintes";
            this.bing.UseVisualStyleBackColor = true;
            this.bing.Click += new System.EventHandler(this.bing_Click);
            // 
            // bplat
            // 
            this.bplat.Location = new System.Drawing.Point(736, 299);
            this.bplat.Margin = new System.Windows.Forms.Padding(4);
            this.bplat.Name = "bplat";
            this.bplat.Size = new System.Drawing.Size(151, 28);
            this.bplat.TabIndex = 13;
            this.bplat.Text = "Mostrar Platos";
            this.bplat.UseVisualStyleBackColor = true;
            this.bplat.Click += new System.EventHandler(this.bplat_Click);
            // 
            // grillaplato
            // 
            this.grillaplato.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaplato.Location = new System.Drawing.Point(612, 107);
            this.grillaplato.Margin = new System.Windows.Forms.Padding(4);
            this.grillaplato.Name = "grillaplato";
            this.grillaplato.RowHeadersWidth = 51;
            this.grillaplato.Size = new System.Drawing.Size(449, 185);
            this.grillaplato.TabIndex = 12;
            // 
            // tplat
            // 
            this.tplat.Location = new System.Drawing.Point(753, 53);
            this.tplat.Margin = new System.Windows.Forms.Padding(4);
            this.tplat.Name = "tplat";
            this.tplat.Size = new System.Drawing.Size(132, 22);
            this.tplat.TabIndex = 11;
            // 
            // tidplat
            // 
            this.tidplat.Location = new System.Drawing.Point(753, 16);
            this.tidplat.Margin = new System.Windows.Forms.Padding(4);
            this.tidplat.Name = "tidplat";
            this.tidplat.Size = new System.Drawing.Size(132, 22);
            this.tidplat.TabIndex = 10;
            this.tidplat.Text = "100XX";
            // 
            // bregplat
            // 
            this.bregplat.Location = new System.Drawing.Point(911, 50);
            this.bregplat.Margin = new System.Windows.Forms.Padding(4);
            this.bregplat.Name = "bregplat";
            this.bregplat.Size = new System.Drawing.Size(151, 28);
            this.bregplat.TabIndex = 9;
            this.bregplat.Text = "Registrar Plato";
            this.bregplat.UseVisualStyleBackColor = true;
            this.bregplat.Click += new System.EventHandler(this.bregplat_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(608, 57);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Nombre del Plato:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(608, 16);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "ID Plato:";
            // 
            // bmen
            // 
            this.bmen.Location = new System.Drawing.Point(136, 716);
            this.bmen.Margin = new System.Windows.Forms.Padding(4);
            this.bmen.Name = "bmen";
            this.bmen.Size = new System.Drawing.Size(151, 28);
            this.bmen.TabIndex = 20;
            this.bmen.Text = "´Mostrar Menú Disponible:";
            this.bmen.UseVisualStyleBackColor = true;
            this.bmen.Click += new System.EventHandler(this.bmen_Click);
            // 
            // grillamen
            // 
            this.grillamen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillamen.Location = new System.Drawing.Point(12, 524);
            this.grillamen.Margin = new System.Windows.Forms.Padding(4);
            this.grillamen.Name = "grillamen";
            this.grillamen.RowHeadersWidth = 51;
            this.grillamen.Size = new System.Drawing.Size(449, 185);
            this.grillamen.TabIndex = 19;
            // 
            // tmen
            // 
            this.tmen.Location = new System.Drawing.Point(155, 416);
            this.tmen.Margin = new System.Windows.Forms.Padding(4);
            this.tmen.Name = "tmen";
            this.tmen.Size = new System.Drawing.Size(132, 22);
            this.tmen.TabIndex = 18;
            // 
            // tnummen
            // 
            this.tnummen.Location = new System.Drawing.Point(155, 379);
            this.tnummen.Margin = new System.Windows.Forms.Padding(4);
            this.tnummen.Name = "tnummen";
            this.tnummen.Size = new System.Drawing.Size(132, 22);
            this.tnummen.TabIndex = 17;
            this.tnummen.Text = "00X";
            // 
            // bregmen
            // 
            this.bregmen.Location = new System.Drawing.Point(310, 453);
            this.bregmen.Margin = new System.Windows.Forms.Padding(4);
            this.bregmen.Name = "bregmen";
            this.bregmen.Size = new System.Drawing.Size(151, 28);
            this.bregmen.TabIndex = 16;
            this.bregmen.Text = "Registrar Menú";
            this.bregmen.UseVisualStyleBackColor = true;
            this.bregmen.Click += new System.EventHandler(this.bregmen_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 420);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 16);
            this.label5.TabIndex = 15;
            this.label5.Text = "Nombre del Menú:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 379);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "Número Menú:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(160, 349);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 16);
            this.label7.TabIndex = 21;
            this.label7.Text = "Registrar Menú:";
            // 
            // tpre
            // 
            this.tpre.Location = new System.Drawing.Point(155, 461);
            this.tpre.Margin = new System.Windows.Forms.Padding(4);
            this.tpre.Name = "tpre";
            this.tpre.Size = new System.Drawing.Size(132, 22);
            this.tpre.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 465);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 16);
            this.label8.TabIndex = 22;
            this.label8.Text = "Precio:";
            // 
            // brec
            // 
            this.brec.Location = new System.Drawing.Point(737, 657);
            this.brec.Margin = new System.Windows.Forms.Padding(4);
            this.brec.Name = "brec";
            this.brec.Size = new System.Drawing.Size(151, 28);
            this.brec.TabIndex = 30;
            this.brec.Text = "Mostrar Recetas";
            this.brec.UseVisualStyleBackColor = true;
            this.brec.Click += new System.EventHandler(this.brec_Click);
            // 
            // grillarec
            // 
            this.grillarec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillarec.Location = new System.Drawing.Point(613, 465);
            this.grillarec.Margin = new System.Windows.Forms.Padding(4);
            this.grillarec.Name = "grillarec";
            this.grillarec.RowHeadersWidth = 51;
            this.grillarec.Size = new System.Drawing.Size(449, 185);
            this.grillarec.TabIndex = 29;
            // 
            // tidplat2
            // 
            this.tidplat2.Location = new System.Drawing.Point(755, 411);
            this.tidplat2.Margin = new System.Windows.Forms.Padding(4);
            this.tidplat2.Name = "tidplat2";
            this.tidplat2.Size = new System.Drawing.Size(132, 22);
            this.tidplat2.TabIndex = 28;
            this.tidplat2.Text = "100XX";
            // 
            // tiding2
            // 
            this.tiding2.Location = new System.Drawing.Point(755, 374);
            this.tiding2.Margin = new System.Windows.Forms.Padding(4);
            this.tiding2.Name = "tiding2";
            this.tiding2.Size = new System.Drawing.Size(132, 22);
            this.tiding2.TabIndex = 27;
            this.tiding2.Text = "000XX";
            // 
            // bregrec
            // 
            this.bregrec.Location = new System.Drawing.Point(912, 408);
            this.bregrec.Margin = new System.Windows.Forms.Padding(4);
            this.bregrec.Name = "bregrec";
            this.bregrec.Size = new System.Drawing.Size(151, 28);
            this.bregrec.TabIndex = 26;
            this.bregrec.Text = "Aumentar Ingrediente";
            this.bregrec.UseVisualStyleBackColor = true;
            this.bregrec.Click += new System.EventHandler(this.bregrec_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(609, 415);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "ID Plato:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(609, 374);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 16);
            this.label10.TabIndex = 24;
            this.label10.Text = "ID Ingrediente:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(734, 349);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(171, 16);
            this.label11.TabIndex = 31;
            this.label11.Text = "Añadir Ingredientes al Plato";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(133, 767);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 16);
            this.label12.TabIndex = 38;
            this.label12.Text = "Contenido del Menú";
            // 
            // grillacont
            // 
            this.grillacont.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillacont.Location = new System.Drawing.Point(12, 883);
            this.grillacont.Margin = new System.Windows.Forms.Padding(4);
            this.grillacont.Name = "grillacont";
            this.grillacont.RowHeadersWidth = 51;
            this.grillacont.Size = new System.Drawing.Size(449, 185);
            this.grillacont.TabIndex = 37;
            // 
            // tidplat3
            // 
            this.tidplat3.Location = new System.Drawing.Point(154, 829);
            this.tidplat3.Margin = new System.Windows.Forms.Padding(4);
            this.tidplat3.Name = "tidplat3";
            this.tidplat3.Size = new System.Drawing.Size(132, 22);
            this.tidplat3.TabIndex = 36;
            this.tidplat3.Text = "100XX";
            // 
            // tnmen
            // 
            this.tnmen.Location = new System.Drawing.Point(154, 792);
            this.tnmen.Margin = new System.Windows.Forms.Padding(4);
            this.tnmen.Name = "tnmen";
            this.tnmen.Size = new System.Drawing.Size(132, 22);
            this.tnmen.TabIndex = 35;
            this.tnmen.Text = "0XX";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(311, 811);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 43);
            this.button1.TabIndex = 34;
            this.button1.Text = "Agregar Contenido al Menú";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 833);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 16);
            this.label13.TabIndex = 33;
            this.label13.Text = "ID Plato:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 792);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 16);
            this.label14.TabIndex = 32;
            this.label14.Text = "Número Menú:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(136, 1076);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(151, 47);
            this.button2.TabIndex = 39;
            this.button2.Text = "´Mostrar Contenido del Menú";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // grillacons
            // 
            this.grillacons.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillacons.Location = new System.Drawing.Point(613, 933);
            this.grillacons.Margin = new System.Windows.Forms.Padding(4);
            this.grillacons.Name = "grillacons";
            this.grillacons.RowHeadersWidth = 51;
            this.grillacons.Size = new System.Drawing.Size(449, 185);
            this.grillacons.TabIndex = 40;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(760, 722);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(128, 16);
            this.label15.TabIndex = 41;
            this.label15.Text = "Consumo del Infante";
            // 
            // tnmen2
            // 
            this.tnmen2.Location = new System.Drawing.Point(756, 833);
            this.tnmen2.Margin = new System.Windows.Forms.Padding(4);
            this.tnmen2.Name = "tnmen2";
            this.tnmen2.Size = new System.Drawing.Size(249, 22);
            this.tnmen2.TabIndex = 44;
            this.tnmen2.Text = "0XX";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(610, 773);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(127, 16);
            this.label16.TabIndex = 43;
            this.label16.Text = "Fecha de Consumo:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(610, 835);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 16);
            this.label17.TabIndex = 42;
            this.label17.Text = "Número Menú:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(610, 806);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(134, 16);
            this.label18.TabIndex = 46;
            this.label18.Text = "Número de Matrícula:";
            // 
            // tmat
            // 
            this.tmat.Location = new System.Drawing.Point(756, 803);
            this.tmat.Margin = new System.Windows.Forms.Padding(4);
            this.tmat.Name = "tmat";
            this.tmat.Size = new System.Drawing.Size(249, 22);
            this.tmat.TabIndex = 47;
            this.tmat.Text = "000-000-XX";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(747, 1126);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 47);
            this.button3.TabIndex = 48;
            this.button3.Text = "Mostrar Consumo de los Niños";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tcan
            // 
            this.tcan.Location = new System.Drawing.Point(756, 863);
            this.tcan.Margin = new System.Windows.Forms.Padding(4);
            this.tcan.Name = "tcan";
            this.tcan.Size = new System.Drawing.Size(249, 22);
            this.tcan.TabIndex = 50;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(610, 865);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 16);
            this.label19.TabIndex = 49;
            this.label19.Text = "Cantidad";
            // 
            // bregcons
            // 
            this.bregcons.Location = new System.Drawing.Point(747, 893);
            this.bregcons.Margin = new System.Windows.Forms.Padding(4);
            this.bregcons.Name = "bregcons";
            this.bregcons.Size = new System.Drawing.Size(151, 28);
            this.bregcons.TabIndex = 51;
            this.bregcons.Text = "Registrar Consumo";
            this.bregcons.UseVisualStyleBackColor = true;
            this.bregcons.Click += new System.EventHandler(this.bregcons_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(373, 1191);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(352, 47);
            this.button4.TabIndex = 52;
            this.button4.Text = "Productos Extra, aquí";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // tfcon
            // 
            this.tfcon.Location = new System.Drawing.Point(756, 767);
            this.tfcon.Name = "tfcon";
            this.tfcon.Size = new System.Drawing.Size(249, 22);
            this.tfcon.TabIndex = 53;
            // 
            // Comida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1163, 554);
            this.Controls.Add(this.tfcon);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.bregcons);
            this.Controls.Add(this.tcan);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tmat);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.tnmen2);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.grillacons);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.grillacont);
            this.Controls.Add(this.tidplat3);
            this.Controls.Add(this.tnmen);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.brec);
            this.Controls.Add(this.grillarec);
            this.Controls.Add(this.tidplat2);
            this.Controls.Add(this.tiding2);
            this.Controls.Add(this.bregrec);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tpre);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.bmen);
            this.Controls.Add(this.grillamen);
            this.Controls.Add(this.tmen);
            this.Controls.Add(this.tnummen);
            this.Controls.Add(this.bregmen);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.bplat);
            this.Controls.Add(this.grillaplato);
            this.Controls.Add(this.tplat);
            this.Controls.Add(this.tidplat);
            this.Controls.Add(this.bregplat);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bing);
            this.Controls.Add(this.grillaing);
            this.Controls.Add(this.ting);
            this.Controls.Add(this.tiding);
            this.Controls.Add(this.breging);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Comida";
            this.Text = "Comida";
            ((System.ComponentModel.ISupportInitialize)(this.grillaing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillaplato)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillamen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillarec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacont)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacons)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button breging;
        private System.Windows.Forms.TextBox tiding;
        private System.Windows.Forms.TextBox ting;
        private System.Windows.Forms.DataGridView grillaing;
        private System.Windows.Forms.Button bing;
        private System.Windows.Forms.Button bplat;
        private System.Windows.Forms.DataGridView grillaplato;
        private System.Windows.Forms.TextBox tplat;
        private System.Windows.Forms.TextBox tidplat;
        private System.Windows.Forms.Button bregplat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bmen;
        private System.Windows.Forms.DataGridView grillamen;
        private System.Windows.Forms.TextBox tmen;
        private System.Windows.Forms.TextBox tnummen;
        private System.Windows.Forms.Button bregmen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tpre;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button brec;
        private System.Windows.Forms.DataGridView grillarec;
        private System.Windows.Forms.TextBox tidplat2;
        private System.Windows.Forms.TextBox tiding2;
        private System.Windows.Forms.Button bregrec;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView grillacont;
        private System.Windows.Forms.TextBox tidplat3;
        private System.Windows.Forms.TextBox tnmen;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView grillacons;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tnmen2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tmat;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox tcan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button bregcons;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DateTimePicker tfcon;
    }
}