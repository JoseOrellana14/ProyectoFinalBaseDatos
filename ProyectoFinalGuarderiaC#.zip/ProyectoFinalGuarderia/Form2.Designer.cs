﻿namespace ProyectoFinal
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.brevnin = new System.Windows.Forms.Button();
            this.tmat = new System.Windows.Forms.TextBox();
            this.tnom = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.grillaninos = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lfbaj = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ttarmen = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tfnac = new System.Windows.Forms.DateTimePicker();
            this.tfbaj = new System.Windows.Forms.DateTimePicker();
            this.tfal = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.comboalergias = new System.Windows.Forms.ComboBox();
            this.baler = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.grillacargo = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.tmat2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tper = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tfpago = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tpago = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tci = new System.Windows.Forms.TextBox();
            this.tnc = new System.Windows.Forms.TextBox();
            this.tntran = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grillaninos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacargo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(262, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reigistrar Infante";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(262, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "¿Qué quiere hacer?";
            // 
            // brevnin
            // 
            this.brevnin.Location = new System.Drawing.Point(626, 19);
            this.brevnin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.brevnin.Name = "brevnin";
            this.brevnin.Size = new System.Drawing.Size(111, 40);
            this.brevnin.TabIndex = 2;
            this.brevnin.Text = "Revisar Infantes Existentes";
            this.brevnin.UseVisualStyleBackColor = true;
            this.brevnin.Click += new System.EventHandler(this.brevnin_Click);
            // 
            // tmat
            // 
            this.tmat.Location = new System.Drawing.Point(111, 124);
            this.tmat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tmat.Name = "tmat";
            this.tmat.Size = new System.Drawing.Size(196, 20);
            this.tmat.TabIndex = 3;
            this.tmat.Text = "000-000-XX";
            // 
            // tnom
            // 
            this.tnom.Location = new System.Drawing.Point(111, 168);
            this.tnom.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tnom.Name = "tnom";
            this.tnom.Size = new System.Drawing.Size(196, 20);
            this.tnom.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 126);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nro. Matrícula:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-1, 171);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nombre del Niño:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-1, 215);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Fecha de Nacimiento:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-1, 258);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Fecha de Alta:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(62, 89);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Registrar un nuevo niño";
            // 
            // grillaninos
            // 
            this.grillaninos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaninos.Location = new System.Drawing.Point(444, 78);
            this.grillaninos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillaninos.Name = "grillaninos";
            this.grillaninos.RowHeadersWidth = 51;
            this.grillaninos.RowTemplate.Height = 24;
            this.grillaninos.Size = new System.Drawing.Size(438, 206);
            this.grillaninos.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(-1, 302);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "¿El niño sigue acudiendo?";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.comboBox1.Location = new System.Drawing.Point(138, 300);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(92, 21);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lfbaj
            // 
            this.lfbaj.AutoSize = true;
            this.lfbaj.Location = new System.Drawing.Point(-1, 337);
            this.lfbaj.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lfbaj.Name = "lfbaj";
            this.lfbaj.Size = new System.Drawing.Size(79, 13);
            this.lfbaj.TabIndex = 17;
            this.lfbaj.Text = "Fecha de Baja:";
            this.lfbaj.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(0, 375);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Tarifa Mensual:";
            // 
            // ttarmen
            // 
            this.ttarmen.Location = new System.Drawing.Point(111, 375);
            this.ttarmen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ttarmen.Name = "ttarmen";
            this.ttarmen.Size = new System.Drawing.Size(196, 20);
            this.ttarmen.TabIndex = 20;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(43, 397);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 40);
            this.button2.TabIndex = 21;
            this.button2.Text = "Registrar nuevo infante";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tfnac
            // 
            this.tfnac.Location = new System.Drawing.Point(111, 211);
            this.tfnac.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tfnac.Name = "tfnac";
            this.tfnac.Size = new System.Drawing.Size(196, 20);
            this.tfnac.TabIndex = 22;
            // 
            // tfbaj
            // 
            this.tfbaj.Location = new System.Drawing.Point(111, 337);
            this.tfbaj.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tfbaj.Name = "tfbaj";
            this.tfbaj.Size = new System.Drawing.Size(196, 20);
            this.tfbaj.TabIndex = 23;
            this.tfbaj.Visible = false;
            // 
            // tfal
            // 
            this.tfal.Location = new System.Drawing.Point(111, 258);
            this.tfal.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tfal.Name = "tfal";
            this.tfal.Size = new System.Drawing.Size(196, 20);
            this.tfal.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(442, 337);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(143, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "¿El niño es alérgico a algo??";
            // 
            // comboalergias
            // 
            this.comboalergias.FormattingEnabled = true;
            this.comboalergias.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.comboalergias.Location = new System.Drawing.Point(616, 331);
            this.comboalergias.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboalergias.Name = "comboalergias";
            this.comboalergias.Size = new System.Drawing.Size(92, 21);
            this.comboalergias.TabIndex = 26;
            this.comboalergias.SelectedIndexChanged += new System.EventHandler(this.comboalergias_SelectedIndexChanged);
            // 
            // baler
            // 
            this.baler.Location = new System.Drawing.Point(736, 328);
            this.baler.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.baler.Name = "baler";
            this.baler.Size = new System.Drawing.Size(111, 40);
            this.baler.TabIndex = 27;
            this.baler.Text = "Registrar Alergia";
            this.baler.UseVisualStyleBackColor = true;
            this.baler.Visible = false;
            this.baler.Click += new System.EventHandler(this.baler_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 472);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 13);
            this.label11.TabIndex = 28;
            this.label11.Text = "Revisar Cargo Mensual:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(718, 661);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 40);
            this.button1.TabIndex = 29;
            this.button1.Text = "Revisar Tarifas";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grillacargo
            // 
            this.grillacargo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillacargo.Location = new System.Drawing.Point(436, 443);
            this.grillacargo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillacargo.Name = "grillacargo";
            this.grillacargo.RowHeadersWidth = 51;
            this.grillacargo.RowTemplate.Height = 24;
            this.grillacargo.Size = new System.Drawing.Size(438, 206);
            this.grillacargo.TabIndex = 30;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(472, 661);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 40);
            this.button3.TabIndex = 31;
            this.button3.Text = "Revisar Cargo Mensual";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tmat2
            // 
            this.tmat2.Location = new System.Drawing.Point(119, 509);
            this.tmat2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tmat2.Name = "tmat2";
            this.tmat2.Size = new System.Drawing.Size(196, 20);
            this.tmat2.TabIndex = 33;
            this.tmat2.Text = "000-000-XX";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 512);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "Matrícula del Infante:";
            // 
            // tper
            // 
            this.tper.Location = new System.Drawing.Point(119, 538);
            this.tper.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tper.Name = "tper";
            this.tper.Size = new System.Drawing.Size(196, 20);
            this.tper.TabIndex = 34;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 540);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 35;
            this.label13.Text = "Período (Mes-Año):";
            // 
            // tfpago
            // 
            this.tfpago.Location = new System.Drawing.Point(119, 594);
            this.tfpago.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tfpago.Name = "tfpago";
            this.tfpago.Size = new System.Drawing.Size(196, 20);
            this.tfpago.TabIndex = 36;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 599);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 13);
            this.label14.TabIndex = 37;
            this.label14.Text = "Fecha de Pago:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 571);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "Monto Pagado:";
            // 
            // tpago
            // 
            this.tpago.Location = new System.Drawing.Point(119, 569);
            this.tpago.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tpago.Name = "tpago";
            this.tpago.Size = new System.Drawing.Size(196, 20);
            this.tpago.TabIndex = 39;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 626);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "CI Encargado:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(9, 652);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 13);
            this.label17.TabIndex = 41;
            this.label17.Text = "Número de Cuenta:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(9, 680);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(124, 13);
            this.label18.TabIndex = 42;
            this.label18.Text = "Número de Transacción:";
            // 
            // tci
            // 
            this.tci.Location = new System.Drawing.Point(119, 622);
            this.tci.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tci.Name = "tci";
            this.tci.Size = new System.Drawing.Size(196, 20);
            this.tci.TabIndex = 43;
            // 
            // tnc
            // 
            this.tnc.Location = new System.Drawing.Point(119, 650);
            this.tnc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tnc.Name = "tnc";
            this.tnc.Size = new System.Drawing.Size(196, 20);
            this.tnc.TabIndex = 44;
            // 
            // tntran
            // 
            this.tntran.Location = new System.Drawing.Point(130, 678);
            this.tntran.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tntran.Name = "tntran";
            this.tntran.Size = new System.Drawing.Size(196, 20);
            this.tntran.TabIndex = 45;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(130, 711);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(111, 40);
            this.button4.TabIndex = 46;
            this.button4.Text = "Registrar Cargo Mensual";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(597, 661);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(111, 40);
            this.button5.TabIndex = 47;
            this.button5.Text = "Actualizar Costo";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(892, 462);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.tntran);
            this.Controls.Add(this.tnc);
            this.Controls.Add(this.tci);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.tpago);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tfpago);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tper);
            this.Controls.Add(this.tmat2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.grillacargo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.baler);
            this.Controls.Add(this.comboalergias);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tfal);
            this.Controls.Add(this.tfbaj);
            this.Controls.Add(this.tfnac);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.ttarmen);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lfbaj);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.grillaninos);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tnom);
            this.Controls.Add(this.tmat);
            this.Controls.Add(this.brevnin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form2";
            this.Text = "Registrar Infante";
            ((System.ComponentModel.ISupportInitialize)(this.grillaninos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacargo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button brevnin;
        private System.Windows.Forms.TextBox tmat;
        private System.Windows.Forms.TextBox tnom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView grillaninos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lfbaj;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ttarmen;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DateTimePicker tfnac;
        private System.Windows.Forms.DateTimePicker tfbaj;
        private System.Windows.Forms.DateTimePicker tfal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboalergias;
        private System.Windows.Forms.Button baler;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView grillacargo;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox tmat2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tper;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker tfpago;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tpago;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tci;
        private System.Windows.Forms.TextBox tnc;
        private System.Windows.Forms.TextBox tntran;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}