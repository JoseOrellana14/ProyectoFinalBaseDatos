﻿namespace ProyectoFinal
{
    partial class Productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.grillaprod = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tidpro = new System.Windows.Forms.TextBox();
            this.tprod = new System.Windows.Forms.TextBox();
            this.tpre = new System.Windows.Forms.TextBox();
            this.tstock = new System.Windows.Forms.TextBox();
            this.tmin = new System.Windows.Forms.TextBox();
            this.bregprod = new System.Windows.Forms.Button();
            this.bprod = new System.Windows.Forms.Button();
            this.grillacom = new System.Windows.Forms.DataGridView();
            this.bcomp = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tprod2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tcompra = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tmat = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tfcompra = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.tcant = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tcos = new System.Windows.Forms.TextBox();
            this.bregcom = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.talert = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.grillaAlerta = new System.Windows.Forms.DataGridView();
            this.grillaReporte = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grillaprod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillaAlerta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillaReporte)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(330, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Compras Extras para los Niños";
            // 
            // grillaprod
            // 
            this.grillaprod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaprod.Location = new System.Drawing.Point(396, 71);
            this.grillaprod.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillaprod.Name = "grillaprod";
            this.grillaprod.RowHeadersWidth = 51;
            this.grillaprod.RowTemplate.Height = 24;
            this.grillaprod.Size = new System.Drawing.Size(446, 167);
            this.grillaprod.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "ID Producto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 102);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nombre Producto:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 128);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Precio:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 153);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Stock:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 179);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Stock Mínimo:";
            // 
            // tidpro
            // 
            this.tidpro.Location = new System.Drawing.Point(116, 65);
            this.tidpro.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tidpro.Name = "tidpro";
            this.tidpro.Size = new System.Drawing.Size(190, 20);
            this.tidpro.TabIndex = 7;
            this.tidpro.Text = "2000X";
            // 
            // tprod
            // 
            this.tprod.Location = new System.Drawing.Point(116, 97);
            this.tprod.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tprod.Name = "tprod";
            this.tprod.Size = new System.Drawing.Size(190, 20);
            this.tprod.TabIndex = 8;
            // 
            // tpre
            // 
            this.tpre.Location = new System.Drawing.Point(116, 124);
            this.tpre.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tpre.Name = "tpre";
            this.tpre.Size = new System.Drawing.Size(190, 20);
            this.tpre.TabIndex = 9;
            // 
            // tstock
            // 
            this.tstock.Location = new System.Drawing.Point(116, 153);
            this.tstock.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tstock.Name = "tstock";
            this.tstock.Size = new System.Drawing.Size(190, 20);
            this.tstock.TabIndex = 10;
            // 
            // tmin
            // 
            this.tmin.Location = new System.Drawing.Point(116, 176);
            this.tmin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tmin.Name = "tmin";
            this.tmin.Size = new System.Drawing.Size(190, 20);
            this.tmin.TabIndex = 11;
            // 
            // bregprod
            // 
            this.bregprod.Location = new System.Drawing.Point(108, 219);
            this.bregprod.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bregprod.Name = "bregprod";
            this.bregprod.Size = new System.Drawing.Size(101, 19);
            this.bregprod.TabIndex = 12;
            this.bregprod.Text = "Registrar Producto";
            this.bregprod.UseVisualStyleBackColor = true;
            this.bregprod.Click += new System.EventHandler(this.bregprod_Click);
            // 
            // bprod
            // 
            this.bprod.Location = new System.Drawing.Point(580, 243);
            this.bprod.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bprod.Name = "bprod";
            this.bprod.Size = new System.Drawing.Size(101, 19);
            this.bprod.TabIndex = 13;
            this.bprod.Text = "Revisar Productos";
            this.bprod.UseVisualStyleBackColor = true;
            this.bprod.Click += new System.EventHandler(this.bprod_Click);
            // 
            // grillacom
            // 
            this.grillacom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillacom.Location = new System.Drawing.Point(396, 271);
            this.grillacom.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillacom.Name = "grillacom";
            this.grillacom.RowHeadersWidth = 51;
            this.grillacom.RowTemplate.Height = 24;
            this.grillacom.Size = new System.Drawing.Size(446, 213);
            this.grillacom.TabIndex = 14;
            // 
            // bcomp
            // 
            this.bcomp.Location = new System.Drawing.Point(580, 499);
            this.bcomp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bcomp.Name = "bcomp";
            this.bcomp.Size = new System.Drawing.Size(101, 19);
            this.bcomp.TabIndex = 15;
            this.bcomp.Text = "Revisar Compras";
            this.bcomp.UseVisualStyleBackColor = true;
            this.bcomp.Click += new System.EventHandler(this.bcomp_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 300);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "ID Producto:";
            // 
            // tprod2
            // 
            this.tprod2.Location = new System.Drawing.Point(121, 297);
            this.tprod2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tprod2.Name = "tprod2";
            this.tprod2.Size = new System.Drawing.Size(186, 20);
            this.tprod2.TabIndex = 17;
            this.tprod2.Text = "2000X";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 271);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "ID Compra:";
            // 
            // tcompra
            // 
            this.tcompra.Location = new System.Drawing.Point(121, 268);
            this.tcompra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tcompra.Name = "tcompra";
            this.tcompra.Size = new System.Drawing.Size(186, 20);
            this.tcompra.TabIndex = 19;
            this.tcompra.Text = "3000X";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 328);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Número de Matrícula:";
            // 
            // tmat
            // 
            this.tmat.Location = new System.Drawing.Point(121, 326);
            this.tmat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tmat.Name = "tmat";
            this.tmat.Size = new System.Drawing.Size(186, 20);
            this.tmat.TabIndex = 21;
            this.tmat.Text = "000-000-XX";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 358);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Fecha de Compra:";
            // 
            // tfcompra
            // 
            this.tfcompra.Location = new System.Drawing.Point(121, 353);
            this.tfcompra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tfcompra.Name = "tfcompra";
            this.tfcompra.Size = new System.Drawing.Size(186, 20);
            this.tfcompra.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 390);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Cantidad Comprada:";
            // 
            // tcant
            // 
            this.tcant.Location = new System.Drawing.Point(121, 388);
            this.tcant.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tcant.Name = "tcant";
            this.tcant.Size = new System.Drawing.Size(186, 20);
            this.tcant.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 425);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "Costo Total:";
            // 
            // tcos
            // 
            this.tcos.Location = new System.Drawing.Point(121, 422);
            this.tcos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tcos.Name = "tcos";
            this.tcos.Size = new System.Drawing.Size(186, 20);
            this.tcos.TabIndex = 27;
            // 
            // bregcom
            // 
            this.bregcom.Location = new System.Drawing.Point(108, 456);
            this.bregcom.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bregcom.Name = "bregcom";
            this.bregcom.Size = new System.Drawing.Size(101, 19);
            this.bregcom.TabIndex = 28;
            this.bregcom.Text = "Registrar Compra";
            this.bregcom.UseVisualStyleBackColor = true;
            this.bregcom.Click += new System.EventHandler(this.bregcom_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(310, 387);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 19);
            this.button1.TabIndex = 29;
            this.button1.Text = "Sacar Total\r\n";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // talert
            // 
            this.talert.Location = new System.Drawing.Point(448, 566);
            this.talert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.talert.Name = "talert";
            this.talert.Size = new System.Drawing.Size(186, 20);
            this.talert.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(252, 569);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "Cantidad Mínima para Alerta:";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(370, 609);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 19);
            this.button3.TabIndex = 31;
            this.button3.Text = "Revisar Inventario";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // grillaAlerta
            // 
            this.grillaAlerta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaAlerta.Location = new System.Drawing.Point(422, 708);
            this.grillaAlerta.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillaAlerta.Name = "grillaAlerta";
            this.grillaAlerta.RowHeadersWidth = 51;
            this.grillaAlerta.RowTemplate.Height = 24;
            this.grillaAlerta.Size = new System.Drawing.Size(411, 213);
            this.grillaAlerta.TabIndex = 30;
            // 
            // grillaReporte
            // 
            this.grillaReporte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaReporte.Location = new System.Drawing.Point(9, 708);
            this.grillaReporte.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grillaReporte.Name = "grillaReporte";
            this.grillaReporte.RowHeadersWidth = 51;
            this.grillaReporte.RowTemplate.Height = 24;
            this.grillaReporte.Size = new System.Drawing.Size(386, 213);
            this.grillaReporte.TabIndex = 34;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(153, 678);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "Reporte de Ventas:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(578, 678);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 13);
            this.label15.TabIndex = 36;
            this.label15.Text = "Alerta de Stock Bajo:";
            // 
            // Productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(851, 428);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.grillaReporte);
            this.Controls.Add(this.talert);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.grillaAlerta);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bregcom);
            this.Controls.Add(this.tcos);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tcant);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.tfcompra);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tmat);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tcompra);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tprod2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.bcomp);
            this.Controls.Add(this.grillacom);
            this.Controls.Add(this.bprod);
            this.Controls.Add(this.bregprod);
            this.Controls.Add(this.tmin);
            this.Controls.Add(this.tstock);
            this.Controls.Add(this.tpre);
            this.Controls.Add(this.tprod);
            this.Controls.Add(this.tidpro);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.grillaprod);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Productos";
            this.Text = "Productos";
            ((System.ComponentModel.ISupportInitialize)(this.grillaprod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillacom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillaAlerta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grillaReporte)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView grillaprod;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tidpro;
        private System.Windows.Forms.TextBox tprod;
        private System.Windows.Forms.TextBox tpre;
        private System.Windows.Forms.TextBox tstock;
        private System.Windows.Forms.TextBox tmin;
        private System.Windows.Forms.Button bregprod;
        private System.Windows.Forms.Button bprod;
        private System.Windows.Forms.DataGridView grillacom;
        private System.Windows.Forms.Button bcomp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tprod2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tcompra;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tmat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker tfcompra;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tcant;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tcos;
        private System.Windows.Forms.Button bregcom;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox talert;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView grillaAlerta;
        private System.Windows.Forms.DataGridView grillaReporte;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}